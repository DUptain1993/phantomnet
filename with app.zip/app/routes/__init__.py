# app/routes/__init__.py

from flask import Blueprint

bp = Blueprint('routes', __name__)